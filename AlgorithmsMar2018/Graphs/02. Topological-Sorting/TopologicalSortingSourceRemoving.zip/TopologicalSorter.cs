﻿using System;
using System.Collections.Generic;
using System.Linq;

public class TopologicalSorter
{

    private Dictionary<string, int> predecessorCount;

    private Dictionary<string, List<string>> graph;

    public TopologicalSorter(Dictionary<string, List<string>> graph)
    {
        this.graph = graph;
    }

    public ICollection<string> TopSort()
    {
        GetPredecessorCount(graph);
        List<string> sorted = new List<string>();
        while (true)
        {
            var nodeToRemove = graph
                .Keys
                .Where(e => predecessorCount[e] == 0)
                .FirstOrDefault();
            if (nodeToRemove == null)
            {
                break;
            }

            foreach (var child in graph[nodeToRemove])
            {
                predecessorCount[child]--;
            }

            graph.Remove(nodeToRemove);
            sorted.Add(nodeToRemove);

        }

        if (graph.Count > 0)
        {
            throw new InvalidOperationException();
        }

        return sorted;
    }

    private void GetPredecessorCount(Dictionary<string, List<string>> graph)
    {
        predecessorCount = new Dictionary<string, int>();

        foreach (var node in graph)
        {
            if (!predecessorCount.ContainsKey(node.Key))
            {
                predecessorCount[node.Key] = 0;
            }

            foreach (var child in node.Value)
            {
                if (!predecessorCount.ContainsKey(child))
                {
                    predecessorCount[child] = 0;
                }

                predecessorCount[child]++;
            }
        }
    }

}
