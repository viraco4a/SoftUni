package GenericArrayCreator;

public class Main {
    public static void main(String[] args) {
//      Integer[] nums = ArrayCreator.<Integer>create( Integer.class, 10, 0);
        Integer[] nums = ArrayCreator.<Integer>create( 10, 0);


        System.out.println();
    }
}
