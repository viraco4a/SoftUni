package Google;

import java.util.Date;

public class Parent {
    private String name;
    private Date birthdy;

    public Parent(String name, Date birthdy) {
        this.name = name;
        this.birthdy = birthdy;
    }

    public String getName() {
        return name;
    }

    public Date getBirthdy() {
        return birthdy;
    }
}
