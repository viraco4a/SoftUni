package Google;

public class Parent {
    private String name;
    private String birthdy;

    public Parent(String name, String birthdy) {
        this.name = name;
        this.birthdy = birthdy;
    }

    public String getName() {
        return name;
    }

    public String getBirthdy() {
        return birthdy;
    }
}
