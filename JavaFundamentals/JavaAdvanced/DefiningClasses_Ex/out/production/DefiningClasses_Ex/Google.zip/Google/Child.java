package Google;

import java.util.Date;

public class Child {
    private String name;
    private Date birthdy;

    public Child(String name, Date birthday) {
        this.name = name;
        this.birthdy = birthday;
    }

    public String getName() {
        return name;
    }

    public Date getBirthdy() {
        return birthdy;
    }
}
