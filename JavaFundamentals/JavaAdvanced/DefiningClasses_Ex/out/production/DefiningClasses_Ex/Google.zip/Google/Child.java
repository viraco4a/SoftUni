package Google;

public class Child {
    private String name;
    private String birthdy;

    public Child(String name, String birthday) {
        this.name = name;
        this.birthdy = birthday;
    }

    public String getName() {
        return name;
    }

    public String getBirthdy() {
        return birthdy;
    }
}
