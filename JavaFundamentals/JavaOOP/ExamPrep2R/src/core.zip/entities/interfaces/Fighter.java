package entities.interfaces;

public interface Fighter extends Machine {

    boolean getAggressiveMode();

    void toggleAggressiveMode();
}
