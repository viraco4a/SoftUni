package say_hello_extended;

public interface Person {
    String getName();
    String sayHello();
}
