package car_shop_extended;

public interface Sellable extends Car {
    Double getPrice();
}
