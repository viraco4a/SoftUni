package border_control;

public interface Identifiable {
    String getId();
}
