package say_hello;

public interface Person {
    String getName();
    String sayHello();
}
