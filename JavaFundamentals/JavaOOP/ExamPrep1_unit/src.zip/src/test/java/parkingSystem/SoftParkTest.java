package parkingSystem;


import org.junit.Assert;
import org.junit.Test;

public class SoftParkTest {
    @Test
    public void testValidImplementationConstructor() {
        SoftPark part = new SoftPark();
        int actualParkCount = part.getParking().size();

        Assert.assertEquals(12, actualParkCount);
    }
}