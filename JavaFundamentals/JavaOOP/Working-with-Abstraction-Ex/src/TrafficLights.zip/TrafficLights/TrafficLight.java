package TrafficLights;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW
}
