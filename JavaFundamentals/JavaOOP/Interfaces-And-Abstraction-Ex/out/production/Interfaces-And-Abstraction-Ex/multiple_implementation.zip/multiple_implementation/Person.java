package multiple_implementation;

public interface Person {
    String getName();
    int getAge();
}
