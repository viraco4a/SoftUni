package multiple_implementation;

public interface Birthable {
    String getBirthDate();
}
