package multiple_implementation;

public interface Identifiable {
    String getId();
}
