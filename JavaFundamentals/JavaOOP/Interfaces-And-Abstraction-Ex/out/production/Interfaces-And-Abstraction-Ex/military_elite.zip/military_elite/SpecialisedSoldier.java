package military_elite;

public interface SpecialisedSoldier extends Private {
    Corps getCorps();
}
