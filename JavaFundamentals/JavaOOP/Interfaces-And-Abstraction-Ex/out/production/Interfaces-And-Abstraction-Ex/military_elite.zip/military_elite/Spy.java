package military_elite;

public interface Spy extends Soldier {
    int getCodeNumber();
}
