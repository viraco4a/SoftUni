package military_elite;

public interface Private extends Soldier {
    double getSalary();
}
