package military_elite;

public enum State {
    inProgress,
    finished
}
