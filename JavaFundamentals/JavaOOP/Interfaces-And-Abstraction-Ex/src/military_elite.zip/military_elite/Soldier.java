package military_elite;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();
}
