package military_elite;

public enum Corps {
    Airforces,
    Marines
}
