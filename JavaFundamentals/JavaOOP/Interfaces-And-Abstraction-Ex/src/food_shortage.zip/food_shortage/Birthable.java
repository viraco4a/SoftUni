package food_shortage;

public interface Birthable {
    String getBirthDate();
}
