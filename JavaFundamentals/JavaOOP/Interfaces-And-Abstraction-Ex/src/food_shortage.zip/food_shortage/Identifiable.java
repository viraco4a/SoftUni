package food_shortage;

public interface Identifiable {
    String getId();
}
