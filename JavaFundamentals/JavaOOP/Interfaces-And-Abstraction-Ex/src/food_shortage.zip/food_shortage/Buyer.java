package food_shortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
