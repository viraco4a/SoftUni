package collection_hierarchy;

public interface MyList extends AddRemovable {
    int getUsed();
}
