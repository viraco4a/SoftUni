package collection_hierarchy;

public interface AddRemovable extends Addable {
    String remove();
}
