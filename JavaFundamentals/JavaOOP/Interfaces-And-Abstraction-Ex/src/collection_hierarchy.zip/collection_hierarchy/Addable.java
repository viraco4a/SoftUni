package collection_hierarchy;

import java.util.List;

public interface Addable {
    int add(String element);
}
