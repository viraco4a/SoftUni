package birthday_celebrations;

public interface Birthable {
    String getBirthDate();
}
