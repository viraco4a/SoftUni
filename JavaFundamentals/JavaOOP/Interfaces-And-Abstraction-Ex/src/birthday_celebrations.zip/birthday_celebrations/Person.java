package birthday_celebrations;

public interface Person {
    String getName();
    int getAge();
}
