package hero;

public class DarkKnight extends Knight {
    protected DarkKnight(String username, int level) {
        super(username, level);
    }
}
