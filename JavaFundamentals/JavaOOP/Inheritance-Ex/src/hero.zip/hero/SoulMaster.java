package hero;

public class SoulMaster extends DarkWizard {
    protected SoulMaster(String username, int level) {
        super(username, level);
    }
}
