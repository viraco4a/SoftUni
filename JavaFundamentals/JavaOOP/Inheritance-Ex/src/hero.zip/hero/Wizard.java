package hero;

public class Wizard extends Hero {
    protected Wizard(String username, int level) {
        super(username, level);
    }
}
