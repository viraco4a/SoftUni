package hero;

public class MuseElf extends Elf {
    protected MuseElf(String username, int level) {
        super(username, level);
    }
}
