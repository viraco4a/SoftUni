package hero;

public class Knight extends Hero {
    protected Knight(String username, int level) {
        super(username, level);
    }
}
