package hero;

public class Elf extends Hero {
    protected Elf(String username, int level) {
        super(username, level);
    }
}
