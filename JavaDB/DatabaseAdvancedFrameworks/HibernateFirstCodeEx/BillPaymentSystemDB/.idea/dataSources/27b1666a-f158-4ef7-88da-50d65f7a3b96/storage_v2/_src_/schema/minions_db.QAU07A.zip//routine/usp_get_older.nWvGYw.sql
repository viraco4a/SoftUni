create procedure usp_get_older(IN minion_id int)
BEGIN
    UPDATE minions AS m
    SET m.age = m.age + 1
    WHERE m.id = minion_id;
END;

