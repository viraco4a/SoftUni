create view v_hr_result_set as
select `hospital`.`employees`.`id`                                                          AS `id`,
       concat(`hospital`.`employees`.`first_name`, ' ', `hospital`.`employees`.`last_name`) AS `Full Name`,
       `hospital`.`employees`.`salary`                                                      AS `salary`
from `hospital`.`employees`
order by `hospital`.`employees`.`department_id`;

