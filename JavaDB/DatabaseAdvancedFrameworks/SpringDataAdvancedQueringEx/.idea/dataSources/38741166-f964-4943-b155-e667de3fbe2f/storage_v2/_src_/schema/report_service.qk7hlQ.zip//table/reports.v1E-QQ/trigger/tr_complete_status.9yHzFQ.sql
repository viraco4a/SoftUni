create trigger tr_complete_status
  before UPDATE
  on reports
  for each row
  BEGIN
    IF (ISNULL(OLD.close_date) <> ISNULL(NEW.close_date)) THEN
        SET NEW.status_id = 'completed';
    END IF;
END;

