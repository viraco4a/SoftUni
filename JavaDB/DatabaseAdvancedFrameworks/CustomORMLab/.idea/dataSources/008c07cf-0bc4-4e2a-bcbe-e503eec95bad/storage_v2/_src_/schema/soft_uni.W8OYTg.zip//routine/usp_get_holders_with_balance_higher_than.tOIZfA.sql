create procedure usp_get_holders_with_balance_higher_than(IN num decimal(19, 4))
  BEGIN
	SELECT
		ah.first_name,
        ah.last_name
	FROM account_holders as ah
    INNER JOIN 
		(SELECT
			a.id,
            a.account_holder_id,
            SUM(a.balance) AS total_balance
		FROM accounts AS a
		GROUP BY a.account_holder_id
		HAVING total_balance > num) AS a
	ON ah.id = a.account_holder_id
    ORDER BY ah.first_name, ah.last_name, ah.id;		
END;

