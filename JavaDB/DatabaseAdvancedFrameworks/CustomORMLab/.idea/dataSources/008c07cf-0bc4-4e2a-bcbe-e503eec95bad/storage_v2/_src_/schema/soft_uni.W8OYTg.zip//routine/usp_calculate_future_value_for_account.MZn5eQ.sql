create procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate decimal(10, 4))
  BEGIN
	SELECT
		h.id,
        h.first_name,
        h.last_name,
        a.balance AS current_balance,
        ufn_calculate_future_value(a.balance, interest_rate, 5) AS balance_in_5_years
	FROM account_holders AS h
    JOIN accounts as a
    ON h.id = a.account_holder_id
    WHERE h.id = account_id
    LIMIT 1;
END;

