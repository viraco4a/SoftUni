create function ufn_calculate_future_value(initial_sum decimal(19, 4), rate double, years int)
  returns decimal(19, 4)
  BEGIN
    RETURN initial_sum * (POW((1 + rate), years));
END;

